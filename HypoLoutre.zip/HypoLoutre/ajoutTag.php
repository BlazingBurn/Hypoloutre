<?php
require_once './connexion.php';

$nomNouveauTag = $_POST["nomNouveauTag"];
$bdd = new Connexion();
$bdd->connexion();

try {
	
	$sql = "SELECT * FROM tag where nomTag = \"$nomNouveauTag\"";
	$requete = $bdd->getBdd()->prepare($sql);
    $requete->execute();
    $rows = $requete->fetchAll();
    if(count($tab) <= 0){
    	$sql2 = "INSERT INTO tag values (\"$nomNouveauTag\")";
    	$requete2 = $bdd->getBdd()->prepare($sql2);
    	$requete2->execute();
    }
    else {
    	throw new Exception("Erreur ce tag existe");
    }

} catch (Exception $e) {
	die("Ce tag existe deja");
}

?>