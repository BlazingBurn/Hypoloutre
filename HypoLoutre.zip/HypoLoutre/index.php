<?php
session_start();
require_once "vue_generique.php";

//afin de recuperer l'affichage des modules
ob_start();

$module = !isset($_GET['module'])?"accueil": htmlspecialchars($_GET['module']);

//mise en place du routeur
switch ($module) {
		case "upload":
		case "connexion":
		case "accueil":
		case "parametre_compte":
		case "recherche":
		case "image":
		case "contact":
		case "politique":
		case "moderation":
		case "soumissionImage":
		case "gestionTickets":
		case "gestionLogs":
			include "./modules/mod_".$module."/mod_".$module.".php";
			break;
		default:
			die("Erreur : module inaccessible");
			break;
}

//recuperation de l'affichage
$module = ob_get_clean();
require('template.php');

?>