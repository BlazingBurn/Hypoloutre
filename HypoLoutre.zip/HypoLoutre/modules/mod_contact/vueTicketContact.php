<?php

class VueTicketContact extends VueGenerique{
	public function __construct () {
	}

	//la vue du ticket, il y a juste la section du ticket contact de disponible, le reste du code se trouve dans index.php normalement.
	function form_ticket(){
		echo '
		 <!--Soumission d\'une requête-->
				<form id="texteGauche" action="index.php?module=ticketContact&action=ajout" method="POST">
						<div class="form-group row container col-md-5">
			   				<label for="exampleInputEmail1">Adresse Email</label>
			   				<input type="email" name="mailUtilisateur" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="ex: mail@domain.com" required>
						</div>
			  			<div class="form-group">
						    <label for="exampleFormControlSelect1">Sélectionner une catégorie de requête</label>
		    				<div class="row container">
		    					<select class="form-control col-md-5" id="exampleFormControlSelect1" name="typeRequete" required>
								    <option>Images qui ne s\'affichent pas</option>
								    <option>Problèmes d\'upload</option>
								    <option>Problèmes de download</option>
								    <option>Problèmes de compte</option>
								    <option>Autres</option>
		    					</select>
							</div>
						</div>
		  				<div class="col-md-6 form-group row">
		            		<label for="exampleFormControlTextarea1">Example textarea</label>
		    				<textarea class="form-control" rows="3" id="textA" name="description" required></textarea>
		  				</div>
		        		<input class="btn btn-primary" type="submit" value="Envoyer">
		        	</form>
		  <img src="DOC/Image03.jpg" id="imgDroite" alt="logo">';
	}
}