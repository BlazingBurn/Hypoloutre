<?php
	include './connexion.php';
Class ModeleContact extends Connexion{
	
	function __construct(){
		
	}	

	//reçoit les données du formulaire en paramètres et insert les données dans la table contact avec un idContact qui s'auto incrémente tout seul dans la table.
	function ajouter_ticket($typeRequete,$description,$mailUtilisateur){
		try{
			$bd = self::$bdd->prepare('INSERT INTO contact(typeRequete,description,mailUtilisateur) VALUES(?,?,?)');
			$tuple = array($typeRequete,$description,$mailUtilisateur);	
			$bd->execute($tuple);
		}catch (PDOException $e) {
	   		$e->getMessage();
	   		echo $e;
	    }
	}
}
?>