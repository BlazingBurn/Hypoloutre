<?php 
	include './modules/mod_contact/vue_contact.php';
	include './modules/mod_contact/modele_contact.php';

	class ContContact
	{
		private $modele;
		private $vue;

		public function __construct(){
			$this->modele = new ModeleContact();
			$this->vue = new VueContact();
		}

		//appel de la vue formulaire du ticket
		public function form_ajout(){
			$this->vue->form_ticket();
			return $this->vue->getAffichage();
		}
		
		public function ajout(){
			//les post du formulaire sont traité dans le controleur et envoyé directement au modèle.
			//il manque le test avec un modele générique qui extends Exception pour renvoyer la réponse à la vue et afficher la vue correspondante.
			$this->modele->ajouter_ticket($_POST['typeRequete'],$_POST['description'],$_POST['mailUtilisateur']);
			$this->vue->envoie_ticket();
			return $this->vue->getAffichage();
		}

		public function initConnexion(){
			$this->modele->initConnexion();
		}

}
?>