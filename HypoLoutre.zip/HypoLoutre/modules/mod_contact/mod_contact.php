<?php  
include './modules/mod_contact/cont_contact.php';

	$ctrl = new ContContact();
	$ctrl->initConnexion();

	$action = !isset($_GET['action'])?"form":$_GET['action'];
	
	switch ($action) {
		case 'form':
			$content = $ctrl->form_ajout();
			break;

		case 'ajout':
			$content = $ctrl->ajout();
			break;
			
		default:
			break;
	}

?>