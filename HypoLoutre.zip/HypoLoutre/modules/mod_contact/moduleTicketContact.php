<?php  
include './modules/mod_contact/controleur.php';

	$ctrl = new ContTicketContact();
	$ctrl->initConnexion();

	VueTicketContact::menu();
	$action = !isset($_GET['action'])?"form":$_GET['action'];
	
	switch ($action) {
		case 'form':
			$content = $ctrl->form_ajout();
			break;

		case 'ajout':
			$ctrl->ajout();
			break;
			
		default:
			break;
	}

?>