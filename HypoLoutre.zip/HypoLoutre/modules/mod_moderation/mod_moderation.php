<?php  
	include 'cont_moderation.php';

	$controleur = new ContModeration();
	$controleur->initConnexion();

	(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "menu";

	switch ($action) {
		
		case "menu":
			$content = $controleur->menu();
			break;
	}