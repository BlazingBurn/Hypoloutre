<?php
include './modules/mod_connexion/modele_connexion.php';
class ModeleModeration extends Connexion{

	public function __construct(){

	}
}
?>