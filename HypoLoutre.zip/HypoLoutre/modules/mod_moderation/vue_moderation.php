<?php

class VueModeration extends VueGenerique{

	public function __construct(){
		parent::__construct();
	}

	function menu_moderation(){
		echo "<div>
				<a href=\"index.php?module=soumissionImage&action=soumissionImage\"><button type=\"button\" class=\"btn btn-secondary\">Soumission des images</button></a>
				<a href=\"index.php?module=gestionLogs&action=logs\"><button type=\"button\" class=\"btn btn-secondary\">Gestion des logs</button></a>
				<a href=\"index.php?module=gestionTickets&action=ticket\"><button type=\"button\" class=\"btn btn-secondary\">Gestion des tickets</button></a>
			</div>";
	}
}
?>