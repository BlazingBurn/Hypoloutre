<?php

class ModeleAccueil {

	function __construct(){
	}

}

?>