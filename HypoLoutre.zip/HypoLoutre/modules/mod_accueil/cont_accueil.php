<?php

include 'modele_accueil.php';
include 'vue_accueil.php';

class ContAccueil {
	
	private $modele;
	private $vue;

	function __construct(){
		$this->modele = new ModeleAccueil();
		$this->vue = new VueAccueil();
	}

}

?>