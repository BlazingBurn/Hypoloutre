<?php

class VueAccueil extends VueGenerique {

	function __construct() {
		parent::__construct();
  }

}

?>

<?php  
include "./modules/mod_recherche/mod_recherche.php";
?>
      

<?php
//recuperation pour l'affichage et l'envoie dans content du template
$content = ob_get_clean();
?>