<?php

include 'cont_accueil.php';


$controleur = new ContAccueil();

(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "";

switch ($action) {
	
}

?>