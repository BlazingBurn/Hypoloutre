<?php
include 'connexion.php';
class ModeleSoumissionImage extends Connexion{

	public function __construct(){

	}

	public function get_images(){
		$bd = self::$bdd->prepare('SELECT * FROM image inner join contenir using(idImage) inner join possederGalerie using(idGalerie) inner join utilisateur using(idUtilisateur) where moderationImage !=1');
		$bd->execute();
		return $bd;
	}

	public function accepter_image($image){
		try{
			$bd = self::$bdd->prepare('UPDATE image set ? = 1');
			$tuple= array($image);
			$bd->execute();
		}catch (PDOException $e) {
	   		$e->getMessage();
	   		echo $e;
	    }
	}

	public function refuser_image($image){
		try{
			$bd = self::$bdd->prepare('UPDATE image set ? = 0');
			$tuple= array($image);
			$bd->execute();
		}catch (PDOException $e) {
	   		$e->getMessage();
	   		echo $e;
	    }
	}
}
?>