<?php
include './modules/mod_soumissionImage/vue_soumissionImage.php';
include './modules/mod_soumissionImage/modele_soumissionImage.php';
class ContSoumissionImage{

		private $modele;
		private $vue;

	public function __construct(){
		$this->modele = new ModeleSoumissionImage();
		$this->vue = new VueSoumissionImage();
	}

	public function affichage(){
		$tab=$this->modele->get_images();
		$this->vue->affich_images($tab);
		return $this->vue->getAffichage();
	}

	public function validation($image){
		var_dump($image);
		$this->modele->accepter_image($image);
		$this->affichage();
	}

	public function refuser($image){
		$this->modele->refuser_image($image);
		$this->affichage();
	}

	public function initConnexion(){
		$this->modele->initConnexion();
	}
}
?>