<?php

class VueSoumissionImage extends VueGenerique{

	public function __construct(){
		parent::__construct();
	}

//modérationImage    0->pas accepté   1->accepté 
	function affich_images($tab){
		$compteur=0;
		echo '
		  			<h1 id="tailleTexte"><strong>Gestion des soumissions d\'image</strong></h1>
  			<div id="divTableau" class="overflow-auto">
	  			<table class="table table-hover table-bordered overflow-auto">
	  				<thead>
	  					<tr>
	  					<th scope="col">N°Image</th>
	  						<th scope="col">Statut</th>
	  						<th scope="col">Description</th>
	  						<th scope="col">Nom d\'utilisateur</th>
	  					</tr>
	  				</thead>
	  				<tbody>
	  	';
	  	while($enregistrement = $tab->fetch(PDO::FETCH_OBJ)){
			$numImage = $enregistrement->idImage;
			$date = $enregistrement->dateAjoutImage;
			$image = $enregistrement->imageURL;
			$titre = $enregistrement->titreImage;
			$statut = $enregistrement->moderationImage;
			$description = $enregistrement->descrImage;
			$pseudo = $enregistrement->pseudoUtilisateur;
			$compteur=$compteur+1;
	  		echo "<tr data-toggle=\"modal\" data-target=\"#exampleModalCenter".$compteur."\">
	  				<th scope=\"row\">".$numImage."</th>
	  				<td>".$statut."</td>
	  				<td>".$description."</td>
	  				<td>".$pseudo."</td>
	  			  </tr>

				<!-- Modal -->
				<div class=\"modal fade\" id=\"exampleModalCenter".$compteur."\" tabindex=\"0\" role=\"dialog\" aria-labelledby=\"exampleModalCenterTitle\" aria-hidden=\"true\">
				  <div class=\"modal-dialog modal-dialog modal-xl largeur overflow-auto\" role=\"document\">
				    <div class=\"modal-content\">
				      <div class=\"modal-header\">
				        <h5 class=\"modal-title\" id=\"exampleModalCenterTitle\">".$titre."</h5>
				        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">
				          <span aria-hidden=\"true\">&times;</span>
				        </button>
				      </div>
				      <div class=\"modal-body\">
				         <div class=\"row\">
					        <div id=\"imgFiche\" class=\"col-md-9\">
					          <img src=\"".$image."\" alt=\"...\" class=\"img-rounded\" id=\"redimension\">
					        </div>
					        <div class=\"col-md-3\">
					          <div class=\"card\">
					            <div class=\"card-body\" id=\"divModalD\">
					              <p>Ajouté par:".$pseudo."</p>
					              <p>Titre:".$titre."</p>
					              <p>Date d'ajout:".$date."</p>
					              <p>Description:".$description."</p>
					              <p>Tags :<span class=\"badge badge-info\">test</span></p>
					            </div>
					          </div>
					        </div>
					      </div>
				      </div>
				      <div class=\"modal-footer\">
				        <a href=\"index.php?module=soumissionImage&action=validation&statut=$statut\"><button class=\"btn btn-primary\" type=\"submit\" value=\"OUI\">Accepter</button></a>
				       <a href=\"index.php?module=soumissionImage&action=refuser&statut=$statut\"><button type=\"submit\" class=\"btn btn-secondary\" value=\"NON\">Refuser</button></a>
				      </div>
				    </div>
				  </div>
				</div>
	  		</div>";
	  	}
	  	echo '	</tbody>
	  		</table>
			';
	  			
	}
}
?>