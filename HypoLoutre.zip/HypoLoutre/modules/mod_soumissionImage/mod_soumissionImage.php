<?php  
	include_once './modules/mod_soumissionImage/cont_soumissionImage.php';

$controleur = new ContSoumissionImage();
$controleur->initConnexion();

(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "soumissionImage";

switch ($action) {
	
	case "soumissionImage":
		$content = $controleur->affichage();
		break;

	case "validation":
		$controleur->validation($_GET['statut']);
		break;

	case 'refuser':
		$controleur->refuser($_GET['statut']);
		break;
}

?>