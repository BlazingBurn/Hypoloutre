<?php 
	include './modules/mod_recherche/vue_recherche.php';
	include './modules/mod_recherche/modele_recherche.php';
	class ContRecherche {
		private $modele;
		private $vue;

		function __construct(){
			$this->modele = new ModeleRecherche();
			$this->vue = new VueRecherche();
		}

		function accueil(){
			$this->vue->barreRecherche();
			$resultat = $this->modele->imgRandom();
			$this->vue->suggestionImage($resultat);
		}

		function resultat($tag,$auteur,$format,$modeTrie){
			$this->vue->barreRecherche();
			$req = $this->modele->getReq($tag,$auteur,$format,$modeTrie);
			$resultat = $this->modele->getResultat($req);
			$this->vue->resultatRecherche($resultat);
			return $this->vue->getAffichage();
		}

		function initConnexion(){
			$this->modele->initConnexion();
		}
	}
?>
