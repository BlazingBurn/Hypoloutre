<?php
	include './modules/mod_recherche/cont_recherche.php';

	$ctrl = new ContRecherche();
	$ctrl->initConnexion();

	$action = !isset($_GET['action'])?"accueil":$_GET['action'];

	switch ($action) {
		case 'accueil':
			$ctrl->accueil();
			break;

		case 'resultat':
			$content = $ctrl->resultat($_POST['tag'],$_POST['auteur'],$_POST['format'],$_POST['modeTrie']);
			
			break;

		default:
			break;
	}
?>