<?php 
include './connexion.php';
class ModeleRecherche extends Connexion
{
	function getReq($tag,$auteur,$format,$modeTrie){
		$from = 'Image ';
		$where = ' WHERE ';
		$tags = explode(" ",strtolower($tag)); #sépare chaque mot
		$tags = array_filter($tags); #enlève les mots vides
		$tags = implode('\' OR nomTag=\'', $tags);

		if (!empty($auteur)) { #Si auteur défini
			$fromAut = 'INNER JOIN Contenir using(idImage) INNER JOIN Possedergalerie using(idGalerie) INNER JOIN Utilisateur using(idUtilisateur)';	
			$where = $where.'pseudoUtilisateur=\''.$auteur.'\' ';			
			if(!empty($tag)){ #Si tag défini
				$from = 'Possedertag INNER JOIN '.$from.'using(idImage) '.$fromAut;
				$where = $where.'AND nomTag=\''.$tags.'\'';
				if(!empty($format)){ #Si format défini
					$where = $where.' AND format=\''.$format.'\'';
				}
			}
			else{ #Si auteur défini
				if(!empty($format)){ #Si format défini
					$where = $where.' AND format=\''.$format.'\'';
				}
				$from = $from.' '.$fromAut;
			}

		}
		else{
			if(!empty($tag)){ #Si tag défini
				$from = $from.'INNER JOIN Possedertag using(idImage)';
				$where = $where.'nomTag=\''.$tags.'\'';

				if(!empty($format)){ #Si format défini
					$where = $where.' AND format=\''.$format.'\'';
				}	
			}
			else{ #si tag non défini
				if(!empty($format)){ #Si format défini
					$where = $where.' format=\''.$format.'\'';
				}
				else{#Si rien défini
					$where = '';
				}
			}
		}
		
		$req = "SELECT DISTINCT imageURL, idImage FROM ".$from.$where." ORDER BY ".$modeTrie." DESC";
		return $req;

	}

	function getResultat($req){
		$bd = self::$bdd->prepare($req);
		$bd->execute();

		return $bd;
	}

	function imgRandom(){ #renvoie 6 images aléatoires
		$bd = self::$bdd->prepare('SELECT DISTINCT imageURL, idImage FROM Image ORDER BY RAND() LIMIT 6;');
		$bd->execute();
		return $bd;
	}
}

?>