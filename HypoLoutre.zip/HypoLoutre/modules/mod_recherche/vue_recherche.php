<?php  
class VueRecherche extends VueGenerique
{
	function __construct() {
		parent::__construct();
	}

	function resultatRecherche($resultat){
		echo "<div id=\"imgRdm\" class=\"card\">
		<div class=\"card-body row\">"; //Résultats
		while($enregistrement = $resultat->fetch(PDO::FETCH_OBJ)){
			$url = $enregistrement->imageURL;
			$id = $enregistrement->idImage;
			echo "<a class=\"col-md-2 resultatImg\" href=\"index.php?module=image&action=info&img=".$id."\"><img class=\"img-fluid\" src=".$url." alt=".$id." onclick=\"incrementNbVues(".$id.")\"></a>";
		}
		echo "</div></div>";
	}

	function suggestionImage($resultat){
		echo "<div class=\"card-header\">
				<h5>Images aléatoires</h5>
			</div>";
		self::resultatRecherche($resultat);
	}

	function barreRecherche(){
		echo "
		<div class=\"row\">
			<div class=\"col-md-12\">
				<form id=\"search\" action=\"index.php?module=recherche&action=resultat\" method=\"post\"> 
					<div class=\"input-group mb-3\">
						<input type=\"text\" class=\"form-control\" name=\"tag\" form=\"search\" placeholder=\"Search\">
						<div class=\"input-group-append\">
							<button class=\"btn btn-success\" type=\"submit\">Go</button>
						</div>
					</div>
					<button id=\"btnFiltre\" data-toggle=\"collapse\" data-target=\"#filtre\" type=\"button\">Afficher le filtre</button>
					<div id=\"filtre\" class=\"collapse\">
						<div class=\"form-row\">
							<!--Infos sur image-->
							<div class=\"form-group offset-md-1 col-md-4 offset-md-1\">
								<div class=\"input-group mb-3\">
									<div class=\"input-group-prepend\">
										<span class=\"input-group-text\">Auteur</span>
									</div>
									<input type=\"text\" class=\"form-control\" form=\"search\" name=\"auteur\">
								</div>

								<div class=\"input-group mb-3\">
									<div class=\"input-group-prepend\">
										<span class=\"input-group-text\">Format</span>
									</div>
									<select class=\"custom-select\" form=\"search\" name=\"format\">
										<option value=\"\">Paysage/Portrait</option>
										<option value=\"paysage\">Paysage</option>
										<option value=\"portrait\">Portrait</option>
									</select>
								</div>
							</div>

							<!--Mode de trie-->
							<div class=\"form-group offset-md-2 col-md-4\">
								<div class=\"offset-md-3 col-md-6 offset-md-3\">
									<div class=\"custom-control custom-radio\">
										<input type=\"radio\" class=\"custom-control-input\" id=\"vue\" form=\"search\" name=\"modeTrie\" value=\"nbVue\">
										<label class=\"custom-control-label\" for=\"vue\">Plus vue</label>
									</div>
									<div class=\"custom-control custom-radio\">
										<input type=\"radio\" class=\"custom-control-input\" id=\"popularite\" form=\"search\" name=\"modeTrie\" value=\"notation\">
										<label class=\"custom-control-label\" for=\"popularite\">Popularité</label>
									</div>
									<div class=\"custom-control custom-radio\">
										<input type=\"radio\" class=\"custom-control-input\" id=\"telechargement\" form=\"search\" name=\"modeTrie\" value=\"nbTelechargement\">
										<label class=\"custom-control-label\" for=\"telechargement\">Téléchargement</label>
									</div>
									<div class=\"custom-control custom-radio\">
										<input type=\"radio\" class=\"custom-control-input\" id=\"date\" form=\"search\" name=\"modeTrie\" value=\"dateAjoutImage\" checked>
										<label class=\"custom-control-label\" for=\"date\">Date d'ajout</label>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>       
			</div>
		</div>";
	}
}

?>