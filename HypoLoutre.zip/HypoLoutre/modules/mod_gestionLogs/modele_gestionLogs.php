<?php
include 'connexion.php';
class ModeleGestionLogs extends Connexion{

	public function __construct(){

	}

	public function get_logs(){
		$bd = self::$bdd->prepare('SELECT * FROM log');
		$bd->execute();
		return $bd;
	}
}
?>