<?php

class VueGestionLogs extends VueGenerique{

	public function __construct(){
		parent::__construct();
	}

	function affich_logs($tab){
		echo '
			<h1 id="tailleTexte"><strong>LOGS</strong></h1>
  			<div id="divTableau" class="overflow-auto">
	  			<table class="table table-hover table-bordered overflow-auto">
	  				<thead>
	  					<tr>
	  					<th scope="col">ID</th>
	  						<th scope="col">Action</th>
	  						<th scope="col">Date de modification</th>
	  						<th scope="col">Description</th>
	  					</tr>
	  				</thead>
	  				<tbody>';
	  	while($enregistrement = $tab->fetch(PDO::FETCH_OBJ)){
			$id = $enregistrement->idLog;
			$action = $enregistrement->actionLog;
			$date = $enregistrement->date_heure;
			$description = $enregistrement->descriptionLog;

	  		echo "<tr>
	  				<th scope=\"row\">".$id."</th>
	  				<td>".$action."</td>
	  				<td>".$date."</td>
	  				<td>".$description."</td>
	  			  </tr>";
	  	}
	  	echo '		</tbody>
	  			</table>
	  		</div>';
	}
}
?>