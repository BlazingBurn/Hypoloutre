<?php  
	include './modules/mod_gestionLogs/cont_gestionLogs.php';

	$controleur = new ContGestionLogs();
	$controleur->initConnexion();

	(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "logs";

	switch ($action) {
		
		case "logs":
			$content = $controleur->affichage();
			break;
	}