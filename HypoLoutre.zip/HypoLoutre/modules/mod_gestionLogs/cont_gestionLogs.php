<?php
include './modules/mod_gestionLogs/vue_gestionLogs.php';
include './modules/mod_gestionLogs/modele_gestionLogs.php';
class ContGestionLogs{

		private $modele;
		private $vue;

	public function __construct(){
		$this->modele = new ModeleGestionLogs();
		$this->vue = new VueGestionLogs();
	}

	public function affichage(){
		$tab=$this->modele->get_logs();
		$this->vue->affich_logs($tab);
		return $this->vue->getAffichage();
	}

	public function initConnexion(){
		$this->modele->initConnexion();
	}
}
?>