<?php

include_once 'cont_upload.php';

$controleur = new ContUpload();
$controleur->initConnexion();

(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "vue";

switch ($action) {
	
	case "upload":
		$content = $controleur->Upload();
		break;
	case 'vue':
		$content = $controleur->vue();
		break;
}

?>