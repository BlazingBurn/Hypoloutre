<?php

include_once 'modele_upload.php';
include_once 'vue_upload.php';

class ContUpload {
	
	private $modele;
	private $vue;

	function __construct(){
		$this->modele = new ModeleUpload();
		$this->vue = new VueUpload();
	}

	function Upload() {
		$this->modele->upload();
		return $this->vue->getAffichage();		
	}

	function initConnexion() {
		$this->modele->initConnexion();
	}

	function vue() {
		$this->vue->vue();
		return $this->vue->getAffichage();
	}

}

?>