<?php

class VueUpload extends VueGenerique {

	function __construct() {
		parent::__construct();
	}

  function vue() {
    echo '<div class="card-body">

<input type="button" class="btn btn-secondary" value="Téléversement d\'image" onClick="AfficherMasquerForm()" />
<div id="FormulaireAfficherMasquer" style="display:none;">
  <section>

    <div id="imgRdm" class="card">
      <div class="card-header">
        <h5>Téléverser une image</h5>
      </div>
      <form method="post" action="index.php?module=upload&action=upload" enctype="multipart/form-data">
        <fieldset>


        <!-- Formulaire : partie gauche : fonction : s\'occuper de l\'image et du choix de l\'image-->
        <div class="formulaireSoumissionImageLeft">

          <div class="card-body">
            <div class="row">
              <div class="col-md-14">
                <img src="img/logo.webp" alt="..." class="img-rounded">
              </div>
            </div>
          </div>

            <input type="file" name="image" id="fileUpload" required="">
            <p><strong>Note:</strong> Seuls les formats .jpg, .jpeg, .gif, .png sont autorisés</p>

        </div>
        <!-- FIN partie gauche-->
          


        <!-- Formulaire : partie droite : fonction : s\'occuper du "titre", de la "description" et des differents "tags" choisies-->
        <div class="formulaireSoumissionImageRight">
          

          <!-- Title input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="titreinput">Titre</label>  
            <div class="col-md-10">
              <input id="titreinput" name="titre" type="text" placeholder="Title" class="form-control input-md" required="">
            </div>
          </div>

          
          <!-- Description input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="descriptioninput">Description</label>
            <div class="col-md-12">
              <textarea id="descriptioninput" name="description" placeholder="Description" class="form-control input-md" rows="8" required=""></textarea>
            </div>
          </div>

          <!-- tag input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="taginput">Selection de Tag</label>
            

            <!-- Selection du tag + ajout d\'un nouveau-->
            <div class="col-md-12">

              <!-- ajout d\'un nouveau tag-->
              <input type="button" class="btn btn-secondary" value="Ajouter un Tag" onClick="AfficherMasquerAjoutTag()" />
              <div id="ajouterTag" style="display:none;">

                      <input id="nomTagInput" name="nomTagInput" type="text" placeholder="nom du tag" class="form-control input-md" value="">
                      <input type="button" class="btn btn-info btn-sm" onclick="AfficherMasquerAjoutTag()" name="" value="Valider">

              </div>

              <!-- Selection du tag-->

   
                ';include_once './selectionTag.php';
                echo '
              

            </div>
          </div>

        </div>
        <!-- FIN partie droite-->

        </fieldset>

        <!-- Button -->
        <!-- Controle la validation-->
        <div class="boutonSoumissionImage">
          <label class="col-md-4 control-label" for="singlebutton"></label>
          <div class="col-md-12">
              <button type="submit" name="submit" class="btn btn-success btn-lg">Valider</button>
          </div>
        </div>

      </form>
    </div>
          
  </section>
</div>
</div>';
  }

}
?>

<?php
//recuperation pour l'affichage et l'envoie dans content du template
//$content = ob_get_clean();
?>