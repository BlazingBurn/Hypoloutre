<?php

include 'enleveAccent.php';
include 'connexion.php';

class ModeleUpload extends Connexion {

	function __construct(){
	}

	function upload() {
    $extensionsImageValide = array('.png', '.gif', '.jpg', '.jpeg');
		$extensionDeImageCurrent = strrchr($_FILES['image']['name'], '.');

		$galerieCourant = "PROJET_IMAGES"; /////a modif

    $filename = basename($_FILES["image"]["name"]);
    $filerror = basename($_FILES["image"]["error"]);

    if($_SERVER["REQUEST_METHOD"] == "POST") {//debut if nb1

      //verifier si pas error
      if(isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {

          // Vérifie l'extension du fichier / le type mine
          if (!in_array($extensionDeImageCurrent, $extensionsImageValide)) {
          	 $erreur = 'L\'extention de l\'image que vous avez essayer d\'upload n\'est pas valide, vous devez uploader une image sous le format : png, gif, jpg ou jpeg...';
          }

          if (!isset($erreur)) {
          	
          	//fonction enleve accent exécuté
          	$filename = EnleveAccent::supprimeAcc($filename);

          	//verification si existe deja
          	if (file_exists("PROJET_IMAGES/".$filename)) {
              echo '<div id="imgRdm" class="card">
                      <div class="card-header">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-md-14">
                              <p>'.$filename." existe deja.".'</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>';
            }
            //si existe pas met le fichier dans le dossier cible
        		else {

              move_uploaded_file($_FILES["image"]["tmp_name"], "./$galerieCourant/".$filename);

              $titreInput = $_POST['titre'];
              $descriptioninput = $_POST['description'];
              //var_dump($titreInput);
              //var_dump($descriptioninput);

              $nomTag1 = $_POST['nomTag'];
              $nomTag2 = $_POST['choix_tag'];
              //var_dump($nomTag1);
              //var_dump($nomTag2);

              $imageURL = "./$galerieCourant/".$filename;
              //var_dump($imageURL);

              //fonction ajout de l'image et caracteristique
              $selectPrepare = self::$bdd->prepare('INSERT INTO image (format, imageURL, descrImage, titreImage) VALUES (:format, :imageURL, :descrImage, :titreImage)');
              $tuple = array(':format' => 'paysage', ':imageURL' => $imageURL, ':descrImage' => $descriptioninput, ':titreImage' => $titreInput);
              $selectPrepare->execute($tuple);
              $tab = $selectPrepare->fetchAll();

              //fonction lie les tags a l'image

               $selectLast = self::$bdd->query('SELECT idImage FROM image ORDER BY idImage DESC LIMIT 0, 1');
               $lastId = $selectLast->fetch();
               //var_dump($lastId['idImage']);
               $selectLast->closeCursor();

               //si 2 tag selectionne
               if ($nomTag2 !== 'vide') {
                 $selectPrepare3 = self::$bdd->prepare('INSERT INTO possedertag (nomTag, idImage) VALUES (:tag1, :idImage1), (:tag2, :idImage2)');
                 $tuple3 = array(':tag1' => $nomTag1,':idImage1' =>$lastId['idImage'], ':idImage2' =>$lastId['idImage'], ':tag2' => $nomTag2); 
              }

              //sinon si 1 seul
              else {
                 $selectPrepare3 = self::$bdd->prepare('INSERT INTO possedertag (nomTag, idImage) VALUES (:tag, :idImage)');
                 $tuple3 = array(':tag' => $nomTag1, ':idImage' => $lastId['idImage']);
              }

              //execution commande principale de liason
              $selectPrepare3->execute($tuple3);
              $tab3 = $selectPrepare3->fetchAll();

              //galerie insertion
              $selectPrepare2 = self::$bdd->prepare('SELECT idGalerie FROM galerie INNER JOIN possedergalerie USING (idGalerie) INNER JOIN utilisateur USING (idUtilisateur) where login =  :idUtilisateur');
              $tuple2 = array(':idUtilisateur' => $_SESSION['login']);
              $selectPrepare2->execute($tuple2);
              $tab = $selectPrepare2->fetch();

              $selectPrepare3 = self::$bdd->prepare('INSERT INTO contenir (idGalerie, idImage) VALUES (:idGalerie, :idImage)');
              $tuple3 = array(':idGalerie' => $tab['idGalerie'],':idImage' =>$lastId['idImage']);
              $selectPrepare3->execute($tuple3); 


              echo '<div id="imgRdm" class="card">
                      <div class="card-header">
                        <div class="card-body">
                          <div class="row">
                            <div class="col-md-14">
                              <p>'."Votre image a bien été téléchargé avec succès.".'</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>';
            }

          }

          else {
            echo "$erreur";
          }

      }
      
      else {
        echo 'Error: $filerror ';
      }

    }//fin if nb1

  }

}


?>