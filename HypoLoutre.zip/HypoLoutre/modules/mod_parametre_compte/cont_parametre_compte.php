<?php

include 'modele_parametre_compte.php';
include 'vue_parametre_compte.php';

class ContParametreCompte {
	
	private $modele;
	private $vue;

	function __construct(){
		$this->modele = new ModeleParametreCompte();
		$this->vue = new VueParametreCompte();
	}

	function initConnexion() {
		$this->modele->initConnexion();
	}

	function recherchedonnee() {
		$result = $this->modele->recherchedonnee();	
		$this->vue->donneeTrouve($result);
		return $this->vue->getAffichage();
	}

	function donneeInsere() {
		$this->modele->donneeInsere();
		return $this->vue->getAffichage();
	}

}

?>