<?php

include 'connexion.php';

class ModeleParametreCompte extends Connexion {

	function __construct(){
	}

	function recherchedonnee() {
		$login = $_SESSION['login'];

		$selectPrepare = self::$bdd->prepare('SELECT pseudoUtilisateur, mailUtilisateur FROM utilisateur where login = :login');
		$tuple = array(':login' => $login);
		$selectPrepare->execute($tuple);
		$tab = $selectPrepare->fetch();
		//var_dump($tab['pseudoUtilisateur']);

		return $tab;
	}

	function donneeInsere() {
		$login = $_SESSION['login'];

		$pseudo = $_POST['pseudo'];
		$mail = $_POST['mail'];

			if ($pseudo !== '' && $mail !== '') {
				$selectPrepare = self::$bdd->prepare('UPDATE utilisateur SET pseudoUtilisateur = :pseudo, mailUtilisateur = :mail where login = :login');
				$tuple = array(':pseudo' => $pseudo, ':mail' => $mail, ':login' => $login);
				$selectPrepare->execute($tuple);
				$tab = $selectPrepare->fetch();
				echo '<div id="imgRdm" class="card">
		                      <div class="card-header">
		                        <div class="card-body">
		                          <div class="row">
		                            <div class="col-md-14">
		                              <p>'."Votre modification a bien ete effectuee".'</p>
		                            </div>
		                          </div>
		                        </div>
		                      </div>
		                    </div>';				
			}
			elseif ($pseudo == '' && $mail !== '') {
				$selectPrepare = self::$bdd->prepare('UPDATE utilisateur SET mailUtilisateur = :mail where login = :login');
				$tuple = array(':mail' => $mail, ':login' => $login);
				$selectPrepare->execute($tuple);
				$tab = $selectPrepare->fetch();
				echo '<div id="imgRdm" class="card">
		                      <div class="card-header">
		                        <div class="card-body">
		                          <div class="row">
		                            <div class="col-md-14">
		                              <p>'."Votre modification a bien ete effectuee".'</p>
		                            </div>
		                          </div>
		                        </div>
		                      </div>
		                    </div>';		
			}
			elseif ($pseudo !== '' && $mail == '') {
				$selectPrepare = self::$bdd->prepare('UPDATE utilisateur SET pseudoUtilisateur = :pseudo where login = :login');
				$tuple = array(':pseudo' => $pseudo, ':login' => $login);
				$selectPrepare->execute($tuple);
				$tab = $selectPrepare->fetch();
				echo '<div id="imgRdm" class="card">
		                      <div class="card-header">
		                        <div class="card-body">
		                          <div class="row">
		                            <div class="col-md-14">
		                              <p>'."Votre modification a bien ete effectuee".'</p>
		                            </div>
		                          </div>
		                        </div>
		                      </div>
		                    </div>';
			}
			else {
				echo '<div id="imgRdm" class="card">
		                      <div class="card-header">
		                        <div class="card-body">
		                          <div class="row">
		                            <div class="col-md-14">
		                              <p>'."Aucune modification effectuee".'</p>
		                            </div>
		                          </div>
		                        </div>
		                      </div>
		                    </div>';
			}	
		
	}

}

?>