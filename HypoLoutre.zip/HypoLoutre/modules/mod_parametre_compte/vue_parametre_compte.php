<?php

class VueParametreCompte extends VueGenerique {

	function __construct() {
		parent::__construct();
	}

  function donneeTrouve($result) {
    echo '<section>

  <div class="row">
    <div class="col-8 col py-3">
      
      <h2 class="titreProfil">Profil</h2>
      <button type="button" class="btn btn-primary btn-sm" onClick="ActivationModification()">Modifier</button>

      <div id="afficherMasquerDonnees">
        <form method="post" class="col px-md-5">
          <fieldset>
            <!-- Login input-->
            <div class="form-group row">
              <label for="colFormLabel" class="col-sm-4 col-form-label">Nom d\'utilisateur</label>
              <div class="col-sm-6">
                <input name="login" id="loginModif" type="text" placeholder="'.$_SESSION['login'].'" class="form-control" id="colFormLabel" disabled>
              </div>
            </div>

              <!-- Pseudo input-->
              <div class="form-group row">
                <label for="colFormLabel" class="col-sm-4 col-form-label">Pseudo</label>  
                <div class="col-md-6">
                  <input name="pseudo" id="pseudoModif" type="text" placeholder="'.$result['pseudoUtilisateur'].'" class="form-control" id="colFormLabel" disabled>
                </div>
              </div>

              <!-- Mail input-->
              <div class="form-group row">
                <label for="colFormLabel" class="col-sm-4 col-form-label">Mail</label>  
                <div class="col-md-6">
                  <input name="mail" id="mailModif" type="email" placeholder="'.$result['mailUtilisateur'].'" class="form-control" id="colFormLabel" disabled>
                </div>
              </div>
          </div>
            
          </fieldset>
          <button type="submit" id="validerModif" style="visibility:hidden;" class="btn btn-secondary btn-sm" formaction="index.php?module=parametre_compte&action=donneeInsere">Valider modification</button>
        </form>

    </div>
    <div class="col-3">
      <img src="img/logo.webp" alt="logo" class="col py-5">
    </div>

  </div>

  <div class="separateurProfil">
  </div>

  <div class="row">
    <div class="col px-md-4 col py-3">

      <div>
        <h2 class="titreProfil">Notifications</h2>

          <div class="form-check">
            <input class="form-check-input" type="radio" name="recevoirNotif" id="radioNotif1" value="option1">
            <label class="form-check-label" for="radioNotif1">
              Accepter de recevoir des notifications par mail
            </label>
          </div>
          <div class="form-check">
            <input class="form-check-input" type="radio" name="ignorerNotif" id="radioNotif2" value="option2">
            <label class="form-check-label" for="radioNotif2">
              Ignorer les notifications
            </label>
          </div>
      </div>

    </div>
  </div>

  <div class="separateurProfil">
  </div>

    </div>
  </div>

</section>';
  }

}

?>



<?php
//recuperation pour l'affichage et l'envoie dans content du template
//$content = ob_get_clean();
?>