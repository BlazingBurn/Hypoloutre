<?php

include 'cont_parametre_compte.php';


$controleur = new ContParametreCompte();
$controleur->initConnexion();

(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = 'recherchedonnee';

switch ($action) {
	
	case 'recherchedonnee':
		$content = $controleur->recherchedonnee();
		break;
	case 'donneeInsere':
		$content = $controleur->donneeInsere();
		break;

}

?>