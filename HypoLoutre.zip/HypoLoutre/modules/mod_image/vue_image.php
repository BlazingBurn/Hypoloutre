<?php  
class VueImage extends VueGenerique
{
  function __construct() {
    parent::__construct();
  }

	function afficheInfos($img){
		$tags = "";
		while($enregistrement = $img->fetch(PDO::FETCH_OBJ)){
			$url = $enregistrement->imageURL;
			$id = $enregistrement->idImage;
			$note = $enregistrement->notation;
			$nbTel = $enregistrement->nbTelechargement;
			$date = $enregistrement->dateAjoutImage;
			$titre = $enregistrement->titreImage;
			$desc = $enregistrement->descrImage;
			$aut = $enregistrement->pseudoUtilisateur;
			$tags .= " ".$enregistrement->nomTag;
		}
		if(!isset($note)){
			$note = "N.A.";
		}
		$tags = explode(" ",$tags);
		$tags = array_filter($tags);
        

		echo "
		<div class=\"row\">
          <div id=\"imgFiche\" class=\"col-md-9\">
            <img src=\"".$url."\" alt=\"".$id."\" class=\"img-rounded\">
          </div>
          <div class=\"col-md-3\">
            <div class=\"card\">
              <div class=\"card-header\">
                <h6>Détails</h6>
              </div>
              <div class=\"card-body\">
                <p>Ajouté par: ".$aut."</p>
                <p>Titre: ".$titre."</p>
                <p>Date d'ajout: ".$date."</p>
                <p>Description: ".$desc."</p>
                <p>Tags :";
		
		for ($i=1; $i <= sizeof($tags); $i++) { 
			echo " <span class=\"badge badge-info\">".$tags[$i]."</span>";
		}

        echo "</p>
                <div class=\"row\">
                  <div class=\"offset-md-4 col-md-4 offset-md-4\">
                    <a href=\"".$url."\" download=\"".$url."\"  onclick=\"incrementNbTel(".$id.")\">
                      <span class=\"fas fa-download\" id=\"ddl\">".$nbTel."</span>
                    </a>
                  </div>
                  <div class=\"container\">
                    <div class=\"row\">
                      <span class=\"fas fa-star\" id=\"star\">".$note."/5</span>
                    </div>
                    <div class=\"container\">
                      <form id=\"noteForm\" action=\"index.php?module=image&action=info&img=".$id."\" method=\"post\">
                        <div class=\"row\">
                          <div class=\"btn-group\" role=\"group\" aria-label=\"Basic example\" id=\"vote\">
          					        <div class=\"starrating risingstar d-flex justify-content-center flex-row-reverse\">
          					            <input type=\"submit\" form=\"noteForm\" id=\"star5\" name=\"noteUser\" value=\"5\" /><label for=\"star5\" title=\"5 étoiles\"></label>
          					            <input type=\"submit\" form=\"noteForm\" id=\"star4\" name=\"noteUser\" value=\"4\" /><label for=\"star4\" title=\"4 étoiles\"></label>
          					            <input type=\"submit\" form=\"noteForm\" id=\"star3\" name=\"noteUser\" value=\"3\" /><label for=\"star3\" title=\"3 étoiles\"></label>
          					            <input type=\"submit\" form=\"noteForm\" id=\"star2\" name=\"noteUser\" value=\"2\" /><label for=\"star2\" title=\"2 étoiles\"></label>
          					            <input type=\"submit\" form=\"noteForm\" id=\"star1\" name=\"noteUser\" value=\"1\" /><label for=\"star1\" title=\"1 étoile\"></label>
          					            <button disabled>Note : </button>
          					        </div>
                          </div>          
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>";
	}
}

?>