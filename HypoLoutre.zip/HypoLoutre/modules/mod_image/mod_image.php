<?php
	include './modules/mod_image/cont_image.php';

	$ctrl = new ContImage();
	$ctrl->initConnexion();

	$action = !isset($_GET['action'])?"info":$_GET['action'];

	switch ($action) {
		case 'info':
			$content = $ctrl->infosImg($_GET['img']);
			break; 

		default:
			break;
	}
?>