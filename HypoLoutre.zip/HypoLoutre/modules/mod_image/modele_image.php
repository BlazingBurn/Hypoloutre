<?php 
include './connexion.php';
class ModeleImage extends Connexion {
	function getImg($idImage){
		$bd = self::$bdd->prepare('SELECT * FROM Possedertag INNER JOIN Image using(idImage) INNER JOIN Contenir using(idImage) INNER JOIN Possedergalerie using(idGalerie) INNER JOIN Utilisateur using(idUtilisateur) WHERE idImage=? ;');
		$bd->execute([$idImage]);
		return $bd;
	}
}

?>