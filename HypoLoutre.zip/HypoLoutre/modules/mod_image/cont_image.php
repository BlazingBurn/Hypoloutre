<?php 
	include './modules/mod_image/vue_image.php';
	include './modules/mod_image/modele_image.php';
	class ContImage
	{
		private $modele;
		private $vue;

		function __construct(){
			$this->modele = new ModeleImage();
			$this->vue = new VueImage();
		}

		function infosImg($idImage){
			$img = $this->modele->getImg($idImage);
			$this->vue->afficheInfos($img);
			return $this->vue->getAffichage();
		}

		function initConnexion(){
			$this->modele->initConnexion();
		}
	}

?>
