<?php

include 'connexion.php';

class ModeleConnexion extends Connexion {

	function __construct(){
	}

	function verifConnexion() {
		$passmot = hash("sha1", $_POST['password']);
		$login = $_POST['login'];

		$selectPrepare = self::$bdd->prepare('SELECT * FROM utilisateur where login = :login AND password = :passmot');
		$tuple = array(':login' => $login, ':passmot' => $passmot);

		$selectPrepare->execute($tuple);
		$tab = $selectPrepare->fetchAll();

		if(count($tab) <= 0){
			echo '<script type="text/javascript">window.alert("Connexion impossible, verifier votre mot de passe et votre login");</script>';
		}
		else {
			echo '<script type="text/javascript">window.alert("Connexion reussie");</script>';
			$_SESSION['login'] = $login;
		}
	}

	function deconnexion() {
		unset($_SESSION['login']);
	}

}

?>