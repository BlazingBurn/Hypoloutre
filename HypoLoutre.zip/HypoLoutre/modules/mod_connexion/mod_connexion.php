<?php

include 'cont_connexion.php';


$controleur = new ContConnexion();
$controleur->initConnexion();

(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "";

switch ($action) {
	
	case "verifConnexion":
		$controleur->verifConnexion();
		break;

	case "deconnexion":
		$controleur->deconnexion();
		break;
}

?>