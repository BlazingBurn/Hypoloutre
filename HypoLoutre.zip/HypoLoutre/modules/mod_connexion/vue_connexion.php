<?php

class VueConnexion extends VueGenerique {

	function __construct() {
		parent::__construct();
	}

	function formConnexion() {
		if (isset ($_SESSION['login']) ) {
			echo "Vous êtes déja connecté sous l'identifiant ".$_SESSION['login'];
			echo "</br>";
			echo "<td>"."<a href=\"index.php?module=connexion&action=deconnexion\">Deconnexion</a>"."</td>";
		}

		else {
			echo "<form action=\"index.php?module=connexion&action=verifConnexion\" method=\"post\">
				
				<label>Nom d'utilisateur</label></br>
					<input type=\"text\" name=\"login\" required></br>

				<label>Mot de passe</label></br>
					<input type=\"password\" name=\"passmot\" required></br>

				<button>Se connecter</button>
			</form>";
		}
	}

	function verifInsertion($verif) {
		if($verif) {
			echo "insertion faite";
		}
		else {
			echo "insertion pas faite";
		}
	}

}

?>

  		<section>
  			<div class="formulaireConnexion">
  				<form method="post" action="index.php?module=connexion&action=verifConnexion">
  					<fieldset>
  						<!-- Form Name -->
  						<h2 class="titreFormConnexion">Connexion :</h2>

  						<!-- Login input-->
  						<div class="form-group">
  							<label class="col-md-4 control-label" for="textinput">Nom d'utilisateur</label>  
  							<div class="col-md-10">
  								<input id="textinput" name="login" type="text" placeholder="Username" class="form-control input-md" required="">
  							</div>
  						</div>

  						<!-- Password input-->
  						<div class="form-group">
  							<label class="col-md-4 control-label" for="passwordinput">Mot de passe</label>
  							<div class="col-md-10">
  								<input id="passwordinput" name="password" type="password" placeholder="!Hypoloutre01" class="form-control input-md" required="">
  							</div>
  						</div>

  						<!-- Checkbox --> 
  						<div class="checkboxConnecte">
  							<input type="checkbox">     
  							<label for="checkbox">Rester connecté</label>
  						</div>

  						<!-- Button -->
  						<div class="boutonConnexion">
  							<label class="col-md-4 control-label" for="singlebutton"></label>
  							<div class="col-md-12">
  								<button type="submit" class="btn btn-primary">Se connecter</button>
  							</div>
  						</div>

  					</fieldset>
  				</form>
  			</div>

  			<div class="coteFormulaireConnexion">
  				<img src="img/logo.webp" alt="logo" class="imgLogoForm">
  				<div>
  					<p class=lienCompte><a href="#">Mot de passe oublié ?</a></p>
  					<p><a href="#" class="lienCompte">Pas de compte ?</a></p>
  				</div>
  			</div>
  		</section>

<?php
//recuperation pour l'affichage et l'envoie dans content du template
$content = ob_get_clean();
?>