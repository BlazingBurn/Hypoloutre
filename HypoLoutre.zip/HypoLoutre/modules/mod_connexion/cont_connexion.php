<?php

include 'modele_connexion.php';
include 'vue_connexion.php';

class ContConnexion {
	
	private $modele;
	private $vue;

	function __construct(){
		$this->modele = new ModeleConnexion();
		$this->vue = new VueConnexion();
	}

	function initConnexion() {
		$this->modele->initConnexion();
	}

	function verifConnexion() {
		$this->modele->verifConnexion();
	}

	function deconnexion() {
		$this->modele->deconnexion();
	}

}

?>