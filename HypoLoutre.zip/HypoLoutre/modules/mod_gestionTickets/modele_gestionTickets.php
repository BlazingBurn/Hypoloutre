<?php
include 'connexion.php';
class ModeleGestionTickets extends Connexion{

	public function __construct(){

	}

	public function get_tickets(){
		$bd = self::$bdd->prepare('SELECT * FROM contact');
		$bd->execute();
		return $bd;
	}
}
?>