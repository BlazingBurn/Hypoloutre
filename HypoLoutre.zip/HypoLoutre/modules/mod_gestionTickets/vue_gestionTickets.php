<?php

class VueGestionTickets extends VueGenerique{

	public function __construct(){
		parent::__construct();
	}

	function affich_tickets($tab){
		echo '
		<h1 id="tailleTexte"><strong>Gestion des tickets</strong></h1>
  			<div id="divTableau" class="overflow-auto">
	  			<table class="table table-hover table-bordered overflow-auto">
	  				<thead>
	  					<tr>
	  					<th scope="col">ID</th>
	  						<th scope="col">Mail</th>
	  						<th scope="col">type</th>
	  						<th scope="col">Description</th>
	  					</tr>
	  				</thead>
	  				<tbody>
	  					
	  					';
	  	while($enregistrement = $tab->fetch(PDO::FETCH_OBJ)){
			$id = $enregistrement->idContact;
			$type = $enregistrement->typeRequete;
			$mail = $enregistrement->mailUtilisateur;
			$description = $enregistrement ->description;

	  		echo "<tr>
	  				<th scope=\"row\">".$id."</th>
	  				<td>".$mail."</td>
	  				<td>".$type."</td>
	  				<td>".$description."</td>
	  			  </tr>";

	  	}
	  	echo "		</tbody>
	  			</table>
	  		</div>;";
	}
}
?>