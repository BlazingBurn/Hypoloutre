<?php  
	include_once './modules/mod_gestionTickets/cont_gestionTickets.php';

$controleur = new ContGestionTickets();
$controleur->initConnexion();

(isset($_GET['action']))? $action = htmlspecialchars($_GET['action']): $action = "ticket";

switch ($action) {
	
	case "ticket":
		$content = $controleur->affichage();
		break;
}

?>