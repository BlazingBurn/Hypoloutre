<?php
include './modules/mod_gestionTickets/vue_gestionTickets.php';
include './modules/mod_gestionTickets/modele_gestionTickets.php';
class ContGestionTickets{

		private $modele;
		private $vue;

	public function __construct(){
		$this->modele = new ModeleGestionTickets();
		$this->vue = new VueGestionTickets();
	}

	public function affichage(){
		$tab=$this->modele->get_tickets();
		$this->vue->affich_tickets($tab);
		return $this->vue->getAffichage();
	}

	public function initConnexion(){
		$this->modele->initConnexion();
	}
}
?>