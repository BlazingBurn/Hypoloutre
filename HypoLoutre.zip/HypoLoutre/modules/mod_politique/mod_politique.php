<?php  
include './modules/mod_politique/cont_politique.php';

	$ctrl = new ContPolitique();
	$ctrl->initConnexion();

	$action = !isset($_GET['action'])?"pol":$_GET['action'];
	
	switch ($action) {
		case 'pol':
			$content = $ctrl->politique();
			break;
			
		default:
			break;
	}

?>