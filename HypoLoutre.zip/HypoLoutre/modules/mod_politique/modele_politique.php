<?php
	include './connexion.php';
Class ModelePolitique extends Connexion{
	
	function __construct(){
		
	}	
}
?>