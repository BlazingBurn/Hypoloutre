<?php 
	include './modules/mod_politique/vue_politique.php';
	include './modules/mod_politique/modele_politique.php';

	class ContPolitique
	{
		private $modele;
		private $vue;

		public function __construct(){
			$this->modele = new ModelePolitique();
			$this->vue = new VuePolitique();
		}

		public function politique(){
			$this->vue->affichePol();
			return $this->vue->getAffichage();
		}

		public function initConnexion(){
			$this->modele->initConnexion();
		}

}
?>