<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">

<!-- Initialisation du header -->
<head>
	<title>HypoLoutre</title>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
	<link href="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.css" rel="stylesheet">
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="./tag_xhr.js" charset="iso_8859-1"></script>
	<script type="text/javascript" src="./increment.js" charset="iso_8859-1"></script>
	<script src="https://unpkg.com/bootstrap-table@1.15.5/dist/bootstrap-table.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.15.5/dist/extensions/toolbar/bootstrap-table-toolbar.min.js"></script>
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<!-- Fin du header-->

<!-- Debut de l'initialisation du nav-->
<body>
	<div class="container">
		<header>
			<div class="row">
				<div class="col-md-12">
					<a href="index.php"><img src="img/logo.webp" alt="logo"></a>
					<div id="btnCo">
						<div class="btn-group" role="group" aria-label="Basic example">
							<button type="button" class="btn btn-secondary" disabled=""><img src="img/avatar.png" alt="avatar"></button>

							<!-- Partie qui gere le bouton connexion/deconnexion -->
							<?php  
							if (isset ($_SESSION['login']) ) {
	  									/*echo "Vous êtes déja connecté sous l'identifiant ".$_SESSION['login'];
	  									echo "</br>";*/
	  									echo '<a href="index.php?module=connexion&action=deconnexion"><button type="button" class="btn btn-secondary">Deconnexion</button></a>';
	  								}
	  								else {
	  									echo '<a href="index.php?module=connexion"><button type="button" class="btn btn-secondary">Connexion</button></a>';
	  								}
	  								?>
	  								
	  							</div>
	  						</div>
	  					</div>
	  				</div>		
	  			</header>
	  		<nav class="navbar navbar-expand-md navbar-dark bg-dark">
	  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span>
	  			</button>
	  			<div class="collapse navbar-collapse" id="navbarNavDropdown">
	  				<ul class="navbar-nav">
	  					<li class="nav-item active">
	  						<a class="nav-link" href="index.php">Accueil<span class="sr-only">(current)</span></a>
	  					</li>

	  					<?php
		  				if (isset ($_SESSION['login']) ) {
	  						echo '<li class="nav-item">
		  						<a class="nav-link" href="index.php?module=upload">Mes galeries</a>
		  						</li>';
		  				}?>
		  				<?php
		  				if (isset ($_SESSION['login']) ) {
		  					echo '<li class="nav-item">
		  						<a class="nav-link" href="index.php?module=moderation">Modération</a>
		  					</li>';
		  				}?>
		  				<?php
		  				if (isset ($_SESSION['login']) ) {
		  					echo '<li>
		  						<a class="nav-link" href="index.php?module=parametre_compte">Paramètre de compte</a>
		  					</li>';
		  				}?>
	  				</ul>
	  			</div>
	  		</nav>
	  			<!-- Fin de l'initialisation du nav-->



	  			<!-- Debut de l'initialisation du contenue de la page-->
	  			<div id="content">
	  				<?= $content ?>	
	  			</div>
	  			<!-- Fin de l'initialisation du contenue de la page-->



	  			<!-- Debut de l'initialisation du footer-->
	  			<footer>
	  				<p>© 2019 - HypoLoutre</p>
	  				<a href="index.php?module=contact&action=form">Nous contacter</a>
	  				<span> | </span>
	  				<a href="index.php?module=politique&action=pol">Politique de confidentialité</a>
	  			</footer>
	  			<!-- Fin de l'initialisation du footer-->

	  			<!-- Fin du div id = container-->
	  		</div>
	  	</body>

	  	</html>