/* variable globale qui contiendra l'objet XHR */
var requete = null;

/* Fonction qui va créer un objet XHR.
 * Cette fonction initialisera la valeur dans la variable globale définie
 */
function creerRequete() {
    try {
        /* On tente de créer un objet XmlHTTPRequest */
        requete = new XMLHttpRequest();
    }
    catch (microsoft) {
        /* Microsoft utilisant une autre technique, on essays de créer un objet ActiveX */
        try {
            requete = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch(autremicrosoft) {
            /* La première méthode a échoué, on en teste une seconde */
            try {
                requete = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch(echec) {
                /* À ce stade, aucune méthode ne fonctionne... mettez donc votre navigateur à jour ;) */
                requete = null;
            }
        }
    }
    if(requete == null) {
        alert('Impossible de créer l\'objet requête,\nVotre navigateur ne semble pas supporter les object XMLHttpRequest.');
    }  
}


//Fonction qui va mettre à jour l'affichage de la page.
function actualiserTags() {
    var listeTag = requete.responseText;
    var blocListe = document.getElementById('blocTags');
    blocListe.innerHTML = listeTag;
}

/* Fonction appelée par la page affichée.
 * Cette fonction va initialiser la création de l'objet XHR puis appeler le code serveur afin de récupérer les données à modifier dans la page.
 */
function getTags(idr) {
    /* Si il n'y a pas d'identifiant de tag, on fait disparaître la seconde liste au cas où elle serait affichée */
    if(idr == 'vide') {
        document.getElementById("blocTags").innerHTML = '';
    }
    else {
        /* appararition d'un message d'attente */
        var blocListe = document.getElementById("blocTags");
        blocListe.innerHTML = "Traitement en cours, veuillez patienter...";
        
        /* On crée l'objet XHR */
        creerRequete();
        /* Définition du fichier de traitement */
        var url = "selectionTagDeuxiemeListe.php?idr="+ idr;
        /* Envoi de la requête à la page de traitement */
        requete.open('GET', url, true);
        
        /* On surveille le changement d'état de la requête qui va passer successivement de 1 à 4 */
        requete.onreadystatechange = function() {
            /* Lorsque l'état est à 4 : requete fini*/
            if(requete.readyState == 4) {
                /* Si on a un statut à 200 : status est OK*/
                if(requete.status == 200) {
                    /* Mise à jour de l'affichage, on appelle la fonction apropriée */
                    actualiserTags();
                }
            }
        };
        //requete.open("GET", url, true);
        requete.send();
    }
}

function AfficherMasquerForm() {
    divInfo = document.getElementById('FormulaireAfficherMasquer');

    if (divInfo.style.display == 'none') {
        divInfo.style.display = 'block';
    }

    else {
        divInfo.style.display = 'none';
    }

}

function AfficherMasquerAjoutTag() {
divInfo = document.getElementById('ajouterTag');

    if (divInfo.style.display == 'none') {
        divInfo.style.display = 'block';
    }

    else {
        var nomNouveauTag = document.getElementById("nomTagInput").value.toLowerCase();
        if (nomNouveauTag.length >= 1) {
            $.ajax({
                url: "ajoutTag.php",
                type: "POST",
                data: 'nomNouveauTag=' + nomNouveauTag,
                dataType: 'html',

                success : function(result,status){
                    divInfo.style.display = 'none';
                    alert( "Le tag " + nomNouveauTag + " a bien ete ajoute.");
                    document.getElementById("nomTagInput").value = "";
                },

                error : function(result,status,erreur) {
                    alert("Erreur lors du lancement du programme, la cause : " + erreur);
                }
            });  
        }
        else {
            divInfo.style.display = 'none';
            alert('L\'operation a ete annule');
        }
    }

}

function ActivationModification() {

    if (divInfo2 = document.getElementById("pseudoModif").disabled == true) {

        divInfo2 = document.getElementById("pseudoModif").disabled = false;
        divInfo3 = document.getElementById("mailModif").disabled = false;
    
        divInfo4 = document.getElementById("validerModif").style.visibility = 'visible';
    }

    else {

        divInfo2 = document.getElementById("pseudoModif").disabled = true;
        divInfo3 = document.getElementById("mailModif").disabled = true;

        divInfo4 = document.getElementById("validerModif").style.visibility = 'hidden';
    }

}