<?php

class Connexion {

	private $_dns = "mysql:host=localhost;dbname=hypoloutre;";
	private $_user = "root";
	private $_password = "hypoloutre";
	
	//pour connexion() : quand besoin d'un objet
	private $_bdd;

	//pour initConnexion() : quand MVC
	protected static $bdd;

	function __construct() {
	}


	public function getDns() {
		return $this->_dns;
	}
	public function getUser() {
		return $this->_user;
	}
	public function getPassword() {
		return $this->_password;
	}

	public function setBdd($PDO) {
		$this->_bdd = $PDO;
	}
	public function getBdd() {
		return $this->_bdd;
	}

	function connexion() {
		try {
			$this->setBdd(new PDO($this->getDns(), $this->getUser(), $this->getPassword(),array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8')));
		} catch (PDOException $e) {
			print "Erreur !: ".$e->getMessage()."<br/>";
			die('Erreur : '.$e->getMessage());
		}	
	}

	function initConnexion() {
		try {
			self::$bdd = new PDO($this->getDns(), $this->getUser(), $this->getPassword(), array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
			/*foreach(self::$bdd->query('SELECT login,password from utilisateur') as $row) {
        		print_r($row);
    		}*/
		} catch (PDOException $e) {
			print "Erreur !: ".$e->getMessage()."<br/>";
			die();
		}
	}

}

?>