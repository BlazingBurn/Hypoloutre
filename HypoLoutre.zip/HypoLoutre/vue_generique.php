<?php

class VueGenerique {

	function __construct(){
		ob_start();
	}

	function getAffichage() {
		return ob_get_clean();
	}

	//creation d'un fonction de verification du resultat
	function result($result) {
		if ($result) {
			echo "<h1>Opération réussite</h1>";
		}
		else {
			echo "<h1>Opération échoué</h1>";
		}
	}

}

?>