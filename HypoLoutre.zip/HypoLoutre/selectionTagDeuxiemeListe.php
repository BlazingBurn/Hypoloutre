<?php

require_once './connexion.php';

$bdd = new Connexion();
$bdd->connexion();

/* On récupère l'identifiant du tag choisie. */
$idr = isset($_GET['idr']) ? $_GET['idr'] : false;

/* Si on a un tag */
if(false !== $idr) {

    /* Cération de la requête pour avoir les autre tag */
    $sql2 = "SELECT nomTag FROM tag WHERE nomTag NOT IN (\"$idr\")";
    //commande sql lancer

    $stmt = $bdd->getBdd()->prepare($sql2);
    $stmt->execute();
    $rows = $stmt->fetchAll(); // on récupère TOUTES les lignes

    /*compteur pour les tags */
    $nd = 0;
    /* On crée un tableau pour les autres tags */
    $otherNomTag = array();


    /* On va mettre les tags dans le tableau */
    foreach( $rows as $row ) {// une ligne à la fois
        $otherNomTag[] = $row['nomTag'];
        $nd++;
    }


    /* Construiction de la liste déroulante */

    $liste = "";
    $liste .= '<select name="choix_tag" id="choixTag">'."\n".'<option value="vide">Choisissez un deuxieme Tags</option>'."\n";
    
    for($d = 0; $d < $nd; $d++) {
        $liste .= '<option value="'.$otherNomTag[$d].'">'.htmlentities($otherNomTag[$d]).'</option>'."\n";
    }

    $liste .= '</select>'."\n";
    
    /* Affichage de la liste déroulante */
    echo($liste);
}

/* Sinon on retourne un message d'erreur */
else {
    echo("<p>Une erreur s'est produite. Le tag sélectionnée comporte une donnée invalide.</p>\n");
}
?>