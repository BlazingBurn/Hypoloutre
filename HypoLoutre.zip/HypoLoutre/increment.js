/*Augmente le nombre de vues d'une image au moment d'un clic*/
function incrementNbVues(idImage){
	$.ajax({
		url: "incrementVues.php",
		type: "POST",
		data: 'idImage=' + idImage,
	});
};

/*Aumente le nombre de Téléchargement en cliquant*/
function incrementNbTel(idImage){
	$.ajax({
		url: "incrementTel.php",
		type: "POST",
		data: 'idImage=' + idImage,

		success : function(result,status){
			document.getElementById('ddl').innerHTML++;
		},		
	});	
}