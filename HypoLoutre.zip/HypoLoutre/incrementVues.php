<?php  
require_once './connexion.php';

$bdd = new Connexion();
$bdd->connexion();

$id = $_POST['idImage'];

$sql = "UPDATE Image SET nbVue=nbVue+1 WHERE idImage=".$id;
$stmt = $bdd->getBdd()->prepare($sql);
$stmt->execute();

?>