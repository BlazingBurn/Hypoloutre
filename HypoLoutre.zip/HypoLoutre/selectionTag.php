<?php

require_once './connexion.php';

$bdd = new Connexion();
$bdd->connexion();

$sql = "SELECT nomTag AS idr, nomTag FROM tag";
/* Connexion et exécution de la requête */
$choixbase = $bdd->getBdd()->prepare($sql);
$choixbase->execute();
$results = $choixbase->fetchAll();
/* Création du tableau PHP des valeurs récupérées */
$tagLISTE = array();
/* Index du département par tableau régional */
$id = 0;
foreach( $results as $result) {
    $tagLISTE[$result['idr']] = $result['nomTag'];
}

echo '<select name="nomTag" id="nomTag" onchange="getTags(this.value)" required="">';
echo '<option value="">- - - Choisissez un TAG - - -</option>';

/* Construction de la première liste : on se sert du tableau PHP */
foreach($tagLISTE as $ntag => $nomTag) {
?>
<option value="<?php echo ($ntag); ?>"><?php echo($nomTag); ?></option>;

<?php
}
echo '</select>';

//On met un bloc avec un id ou va s'insérer le code de la seconde liste déroulande
echo '<span id="blocTags"></span><br/>';

?>