-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 16 jan. 2020 à 13:33
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `hypoloutre`
--

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

DROP TABLE IF EXISTS `commentaire`;
CREATE TABLE IF NOT EXISTS `commentaire` (
  `idCommentaire` int(11) NOT NULL AUTO_INCREMENT,
  `contenuCommentaire` text NOT NULL,
  PRIMARY KEY (`idCommentaire`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `commentaire`
--

INSERT INTO `commentaire` (`idCommentaire`, `contenuCommentaire`) VALUES
(1, 'oh j\'ai le meme principe go regarde ma galerie'),
(2, 'Ah ouai effectivement t\'a le meme principe, trop bien cette image elle doit te ressembler ');

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `idContact` int(11) NOT NULL AUTO_INCREMENT,
  `typeRequete` varchar(32) NOT NULL,
  `description` text NOT NULL,
  `mailUtilisateur` varchar(64) NOT NULL,
  PRIMARY KEY (`idContact`),
  KEY `mailUtilisateur` (`mailUtilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`idContact`, `typeRequete`, `description`, `mailUtilisateur`) VALUES
(1, '', 'Bonjour j\'aimerai organise un octogone avec l\'utilisateur test1 afin de régler nos compte merci de bien vouloir l\'organiser', 'JAIPASDIDEE@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `contenir`
--

DROP TABLE IF EXISTS `contenir`;
CREATE TABLE IF NOT EXISTS `contenir` (
  `idGalerie` int(11) NOT NULL,
  `idImage` int(11) NOT NULL,
  PRIMARY KEY (`idGalerie`,`idImage`),
  KEY `idGalerie` (`idGalerie`),
  KEY `idImage` (`idImage`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `contenir`
--

INSERT INTO `contenir` (`idGalerie`, `idImage`) VALUES
(2, 2),
(2, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(3, 8),
(3, 9),
(3, 10),
(3, 11);

-- --------------------------------------------------------

--
-- Structure de la table `ecrire`
--

DROP TABLE IF EXISTS `ecrire`;
CREATE TABLE IF NOT EXISTS `ecrire` (
  `idUtilisateur` int(11) NOT NULL,
  `idCommentaire` int(11) NOT NULL,
  `dat_ajout` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idUtilisateur`,`idCommentaire`),
  KEY `idCommentaire` (`idCommentaire`),
  KEY `idUtilisateur` (`idUtilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `ecrire`
--

INSERT INTO `ecrire` (`idUtilisateur`, `idCommentaire`, `dat_ajout`) VALUES
(2, 2, '2019-12-10 09:29:38'),
(3, 1, '2019-12-10 09:28:10');

-- --------------------------------------------------------

--
-- Structure de la table `entreprise`
--

DROP TABLE IF EXISTS `entreprise`;
CREATE TABLE IF NOT EXISTS `entreprise` (
  `nomEntreprise` varchar(16) NOT NULL,
  `numEntreprise` varchar(10) NOT NULL,
  `mailEntreprise` varchar(64) NOT NULL,
  PRIMARY KEY (`nomEntreprise`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entreprise`
--

INSERT INTO `entreprise` (`nomEntreprise`, `numEntreprise`, `mailEntreprise`) VALUES
('HypoLoutre', '0178487578', 'hypoloutre@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `evaluer`
--

DROP TABLE IF EXISTS `evaluer`;
CREATE TABLE IF NOT EXISTS `evaluer` (
  `idUtilisateur` int(11) NOT NULL,
  `idImage` int(11) NOT NULL,
  `note` int(11) NOT NULL,
  PRIMARY KEY (`idUtilisateur`,`idImage`),
  KEY `evaluer_ibfk_idImage` (`idImage`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `galerie`
--

DROP TABLE IF EXISTS `galerie`;
CREATE TABLE IF NOT EXISTS `galerie` (
  `idGalerie` int(11) NOT NULL AUTO_INCREMENT,
  `titreGalerie` varchar(32) NOT NULL DEFAULT 'default',
  `dateCreationGalerie` timestamp NOT NULL DEFAULT current_timestamp(),
  `statutGalerie` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idGalerie`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `galerie`
--

INSERT INTO `galerie` (`idGalerie`, `titreGalerie`, `dateCreationGalerie`, `statutGalerie`) VALUES
(1, 'default', '2019-12-10 08:38:55', 0),
(2, 'default', '2019-12-10 08:40:30', 0),
(3, 'default', '2019-12-10 09:22:34', 0);

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `idImage` int(11) NOT NULL AUTO_INCREMENT,
  `format` varchar(64) NOT NULL,
  `imageURL` varchar(128) NOT NULL,
  `moderationImage` tinyint(1) NOT NULL DEFAULT 0,
  `descrImage` text NOT NULL,
  `statutImage` tinyint(1) NOT NULL DEFAULT 1,
  `dateAjoutImage` timestamp NOT NULL DEFAULT current_timestamp(),
  `nbTelechargement` int(11) NOT NULL DEFAULT 0,
  `nbVue` int(11) NOT NULL DEFAULT 0,
  `notation` int(11) DEFAULT NULL,
  `titreImage` varchar(32) NOT NULL,
  PRIMARY KEY (`idImage`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `image`
--

INSERT INTO `image` (`idImage`, `format`, `imageURL`, `moderationImage`, `descrImage`, `statutImage`, `dateAjoutImage`, `nbTelechargement`, `nbVue`, `notation`, `titreImage`) VALUES
(2, 'paysage', 'PROJET_IMAGES/Image02.jpg', 1, 'Regarde ce chat ouah il ose', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image02'),
(3, 'paysage', 'PROJET_IMAGES/Image03.jpg', 1, 'Grenouille', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image03'),
(4, 'paysage', 'PROJET_IMAGES/Image04.jpeg', 1, 'otruge', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image04'),
(5, 'paysage', 'PROJET_IMAGES/Image05.jpg', 1, 'oh shit', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image05'),
(6, 'paysage', 'PROJET_IMAGES/Image06.jpg', 1, 'oh regarde il est tout mign.... Ah non tout dégueulasse', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image06'),
(7, 'paysage', 'PROJET_IMAGES/Image07.jpg', 1, '-Regarde ce chien il est beau ? -C\'est pas un chien. -Ah bon, effectivement on dirais que c\'est toi !!!', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image07'),
(8, 'paysage', 'PROJET_IMAGES/Image08.jpg', 1, 'oh my god this drop kick is awesome', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image08'),
(9, 'paysage', 'PROJET_IMAGES/Image09.jpg', 1, '\"You\'re next\"', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image09'),
(10, 'paysage', 'PROJET_IMAGES/Image10.jpg', 1, 'yes kick !! yes ! yes ! yes !', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image10'),
(11, 'portrait', 'PROJET_IMAGES/Image11.jpg', 1, '-Regarde comment il.. -Arrête cette blague tu me la déjà faite -OK, bon bah direct alors. -De Quoi direct ? -Bah vu la coupe et la gueule qu\'il a c\'est forcement toi !!!', 1, '2019-12-10 09:18:56', 0, 0, NULL, 'Image11');

-- --------------------------------------------------------

--
-- Structure de la table `log`
--

DROP TABLE IF EXISTS `log`;
CREATE TABLE IF NOT EXISTS `log` (
  `idLog` int(11) NOT NULL AUTO_INCREMENT,
  `actionLog` varchar(128) NOT NULL,
  `date_heure` timestamp NOT NULL DEFAULT current_timestamp(),
  `descriptionLog` varchar(264) NOT NULL,
  PRIMARY KEY (`idLog`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `modifiercom`
--

DROP TABLE IF EXISTS `modifiercom`;
CREATE TABLE IF NOT EXISTS `modifiercom` (
  `idUtilisateur` int(11) NOT NULL,
  `idCommentaire` int(11) NOT NULL,
  `date_modif` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idUtilisateur`,`idCommentaire`),
  KEY `idUtilisateur` (`idUtilisateur`),
  KEY `idCommentaire` (`idCommentaire`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `modifiergalerie`
--

DROP TABLE IF EXISTS `modifiergalerie`;
CREATE TABLE IF NOT EXISTS `modifiergalerie` (
  `idUtilisateur` int(11) NOT NULL,
  `idGalerie` int(11) NOT NULL,
  PRIMARY KEY (`idUtilisateur`,`idGalerie`),
  KEY `idUtilisateur` (`idUtilisateur`),
  KEY `idGalerie` (`idGalerie`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `possedercommentaire`
--

DROP TABLE IF EXISTS `possedercommentaire`;
CREATE TABLE IF NOT EXISTS `possedercommentaire` (
  `idCommentaire` int(11) NOT NULL,
  `idImage` int(11) NOT NULL,
  PRIMARY KEY (`idCommentaire`,`idImage`),
  KEY `idCommentaire` (`idCommentaire`),
  KEY `idImage` (`idImage`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `possedercommentaire`
--

INSERT INTO `possedercommentaire` (`idCommentaire`, `idImage`) VALUES
(1, 7),
(2, 11);

-- --------------------------------------------------------

--
-- Structure de la table `possedergalerie`
--

DROP TABLE IF EXISTS `possedergalerie`;
CREATE TABLE IF NOT EXISTS `possedergalerie` (
  `idUtilisateur` int(11) NOT NULL,
  `idGalerie` int(11) NOT NULL,
  PRIMARY KEY (`idUtilisateur`,`idGalerie`),
  KEY `idUtilisateur` (`idUtilisateur`),
  KEY `idGalerie` (`idGalerie`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `possedergalerie`
--

INSERT INTO `possedergalerie` (`idUtilisateur`, `idGalerie`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Structure de la table `possedertag`
--

DROP TABLE IF EXISTS `possedertag`;
CREATE TABLE IF NOT EXISTS `possedertag` (
  `nomTag` varchar(16) NOT NULL,
  `idImage` int(11) NOT NULL,
  PRIMARY KEY (`nomTag`,`idImage`),
  KEY `nomTag` (`nomTag`),
  KEY `idImage` (`idImage`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `possedertag`
--

INSERT INTO `possedertag` (`nomTag`, `idImage`) VALUES
('animaux', 2),
('animaux', 3),
('animaux', 4),
('animaux', 6),
('animaux', 7),
('animaux', 11),
('autruche', 4),
('baby', 6),
('catch', 8),
('catch', 9),
('catch', 10),
('chat', 2),
('joke', 2),
('joke', 3),
('joke', 5),
('kermit', 3),
('lama', 6),
('lama', 7),
('lama', 11);

-- --------------------------------------------------------

--
-- Structure de la table `questionner`
--

DROP TABLE IF EXISTS `questionner`;
CREATE TABLE IF NOT EXISTS `questionner` (
  `idUtilisateur` int(11) NOT NULL,
  `idContact` int(11) NOT NULL,
  PRIMARY KEY (`idUtilisateur`,`idContact`),
  KEY `idUtilisateur` (`idUtilisateur`),
  KEY `idContact` (`idContact`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `questionner`
--

INSERT INTO `questionner` (`idUtilisateur`, `idContact`) VALUES
(3, 1);

-- --------------------------------------------------------

--
-- Structure de la table `tag`
--

DROP TABLE IF EXISTS `tag`;
CREATE TABLE IF NOT EXISTS `tag` (
  `nomTag` varchar(16) NOT NULL,
  PRIMARY KEY (`nomTag`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tag`
--

INSERT INTO `tag` (`nomTag`) VALUES
('animaux'),
('autruche'),
('baby'),
('catch'),
('chat'),
('joke'),
('kermit'),
('lama');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `idUtilisateur` int(11) NOT NULL AUTO_INCREMENT,
  `pseudoUtilisateur` varchar(64) NOT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL,
  `mailUtilisateur` varchar(64) NOT NULL,
  `roleUtilisateur` varchar(16) NOT NULL,
  `imageProfilUtilisateurURL` varchar(128) NOT NULL,
  `dateCreationUtilisateur` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idUtilisateur`),
  KEY `mailUtilisateur` (`mailUtilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`idUtilisateur`, `pseudoUtilisateur`, `login`, `password`, `mailUtilisateur`, `roleUtilisateur`, `imageProfilUtilisateurURL`, `dateCreationUtilisateur`) VALUES
(1, 'root', 'root', 'dc76e9f0c0006e8f919e0c515c66dbba3982f785', 'hypoloutre@gmail.com', 'admin', '', '2019-12-10 08:36:37'),
(2, 'test', 'test', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3', 'test@gmail.com', 'user', '', '2019-12-10 08:40:07'),
(3, 'jAiPasDIdee', 'pasIdee', '6397b0465961110d796f6842242fb2e0eaae706f', 'JAIPASDIDEE@gmail.com', 'user', '', '2019-12-10 09:22:22');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `fk_mailUtilsateur` FOREIGN KEY (`mailUtilisateur`) REFERENCES `utilisateur` (`mailUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `contenir`
--
ALTER TABLE `contenir`
  ADD CONSTRAINT `contenir_ibfk_idGalerie` FOREIGN KEY (`idGalerie`) REFERENCES `galerie` (`idGalerie`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contenir_ibfk_idImage` FOREIGN KEY (`idImage`) REFERENCES `image` (`idImage`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `ecrire`
--
ALTER TABLE `ecrire`
  ADD CONSTRAINT `ecrire_ibfk_idCommentaire` FOREIGN KEY (`idCommentaire`) REFERENCES `commentaire` (`idCommentaire`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ecrire_ibfk_idUtilisateur` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `evaluer`
--
ALTER TABLE `evaluer`
  ADD CONSTRAINT `evaluer_ibfk_idImage` FOREIGN KEY (`idImage`) REFERENCES `image` (`idImage`),
  ADD CONSTRAINT `evaluer_ibfk_idUtilisateur` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`);

--
-- Contraintes pour la table `modifiercom`
--
ALTER TABLE `modifiercom`
  ADD CONSTRAINT `modifiercom_ibfk_idCommentaire` FOREIGN KEY (`idCommentaire`) REFERENCES `commentaire` (`idCommentaire`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modifiercom_ibfk_idUtilisateur` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `modifiergalerie`
--
ALTER TABLE `modifiergalerie`
  ADD CONSTRAINT `modifierGalerie_ibfk_idGalerie` FOREIGN KEY (`idGalerie`) REFERENCES `galerie` (`idGalerie`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modifierGalerie_ibfk_idUtilisateur` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `possedercommentaire`
--
ALTER TABLE `possedercommentaire`
  ADD CONSTRAINT `possedercommentaire_ibfk_idCommentaire` FOREIGN KEY (`idCommentaire`) REFERENCES `commentaire` (`idCommentaire`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `possedercommentaire_ibfk_idImage` FOREIGN KEY (`idImage`) REFERENCES `image` (`idImage`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `possedergalerie`
--
ALTER TABLE `possedergalerie`
  ADD CONSTRAINT `possederGalerie_ibfk_idGalerie` FOREIGN KEY (`idGalerie`) REFERENCES `galerie` (`idGalerie`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `possederGalerie_ibfk_idUtilisateur` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `possedertag`
--
ALTER TABLE `possedertag`
  ADD CONSTRAINT `possederTag_ibfk_idImage` FOREIGN KEY (`idImage`) REFERENCES `image` (`idImage`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `possederTag_ibfk_nomTag` FOREIGN KEY (`nomTag`) REFERENCES `tag` (`nomTag`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `questionner`
--
ALTER TABLE `questionner`
  ADD CONSTRAINT `questionner_ibfk_idContact` FOREIGN KEY (`idContact`) REFERENCES `contact` (`idContact`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questionner_ibfk_idUtilisateur` FOREIGN KEY (`idUtilisateur`) REFERENCES `utilisateur` (`idUtilisateur`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
